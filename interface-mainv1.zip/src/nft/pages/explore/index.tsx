import Banner from 'nft/components/explore/Banner'

const NftExplore = () => {
  return (
    <>
      <Banner />
    </>
  )
}

export default NftExplore
