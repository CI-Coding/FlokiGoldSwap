const Sell = () => {
  return <div>Sell NFTs</div>
}

export default Sell
