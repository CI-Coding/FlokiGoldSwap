const Asset = () => {
  return <div>NFT Details Page</div>
}

export default Asset
